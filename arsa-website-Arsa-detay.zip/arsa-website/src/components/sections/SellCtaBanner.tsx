import Link from 'next/link';

export default function SellCtaBanner() {
  return (
    <section className="py-12 bg-dark-charcoal">
      <div className="container-custom text-center">
        <h2 className="text-2xl sm:text-3xl font-black text-white mb-3">
          Arsanızı satmak mı istiyorsunuz?
        </h2>
        <p className="text-gray-400 mb-6">
          Fırsatlarla uğraşmayın. Bize satın, paranız hemen hesabınıza geçsin.
        </p>
        <Link
          href="/arsa-sat"
          className="inline-flex items-center gap-2 bg-white text-dark-charcoal px-6 py-3 rounded-xl font-bold text-sm hover:bg-gray-100 transition-colors"
        >
          Hemen Teklif Alın →
        </Link>
      </div>
    </section>
  );
}
