import Icon from '@/components/ui/Icon';

const features = [
  {
    icon: 'speed',
    title: 'Hızlı Değerleme',
    description: 'Uzman ekibimizle piyasa analizi yaparak arsanızın gerçek değerini saatler içinde belirleriz.',
  },
  {
    icon: 'payments',
    title: 'Nakit Ödeme',
    description: 'Tapu devri ile eş zamanlı olarak ödemenizi banka yoluyla güvenli bir şekilde gerçekleştirirsiniz.',
  },
  {
    icon: 'gavel',
    title: 'Hukuki Destek',
    description: 'Veraset, intikal veya hisseli tapu sorunlarında hukuk departmanımız size rehberlik eder.',
  },
  {
    icon: 'money_off',
    title: 'Komisyon Yok',
    description: 'Doğrudan alıcı olduğumuz için emlakçı komisyonu veya hizmet bedeli ödemezsiniz.',
  },
  {
    icon: 'public',
    title: 'Türkiye Geneli',
    description: 'Sadece büyük şehirlerde değil, Türkiye\'nin her yerindeki arazileriniz için teklif veriyoruz.',
  },
  {
    icon: 'task_alt',
    title: 'Kolay İşlem',
    description: 'Siz sadece imzaya gelirsiniz, tapu harcı ve döner sermaye masraflarını biz karşılarız.',
  },
];

export default function WhyUsSection() {
  return (
    <section className="py-16 bg-background-light">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-black text-dark-charcoal tracking-tight mb-3">
            Neden Bizi Tercih Etmelisiniz?
          </h2>
          <p className="text-secondary-text">
            Süreci sizin için basitleştiriyor, güvenli ve hızlı ticaret sunuyoruz.
          </p>
        </div>

        {/* Features Grid - 3x2 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-6 border border-gray-100 hover:border-primary/20 hover:shadow-lg transition-all duration-300"
            >
              {/* Icon */}
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <Icon name={feature.icon} className="!text-[24px] text-primary" />
              </div>

              {/* Content */}
              <h3 className="text-lg font-bold text-dark-charcoal mb-2">
                {feature.title}
              </h3>
              <p className="text-secondary-text text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
