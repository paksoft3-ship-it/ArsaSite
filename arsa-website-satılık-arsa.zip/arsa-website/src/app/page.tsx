import HeroSection from '@/components/sections/HeroSection';
import FeaturedListings from '@/components/sections/FeaturedListings';
import SellCtaBanner from '@/components/sections/SellCtaBanner';
import WhyUsSection from '@/components/sections/WhyUsSection';
import FAQPreview from '@/components/sections/FAQPreview';
import ContactCTA from '@/components/sections/ContactCTA';

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <FeaturedListings />
      <SellCtaBanner />
      <WhyUsSection />
      <FAQPreview />
      <ContactCTA />
    </>
  );
}
