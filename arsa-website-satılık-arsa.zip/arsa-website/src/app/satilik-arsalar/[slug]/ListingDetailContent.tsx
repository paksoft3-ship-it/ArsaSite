'use client';

import Link from 'next/link';
import type { Listing } from '@/types';
import listingsData from '@/data/listings.json';
import siteConfig from '@/data/site-config.json';
import Icon from '@/components/ui/Icon';
import { formatPriceShort, formatArea, getCategoryColorClasses, generateWhatsAppLink } from '@/lib/utils';

interface Props {
  listing: Listing;
}

export default function ListingDetailContent({ listing }: Props) {
  const category = listingsData.categories.find((c) => c.id === listing.category);
  const categoryColors = category ? getCategoryColorClasses(category.color) : getCategoryColorClasses('emerald');

  const handleWhatsAppClick = () => {
    const message = `Merhaba, "${listing.title}" ilanı hakkında bilgi almak istiyorum.

📍 Konum: ${listing.district}, ${listing.city}
📐 Büyüklük: ${listing.size} m²
💰 Fiyat: ${formatPriceShort(listing.price)}

Detaylı bilgi alabilir miyim?`;

    window.open(generateWhatsAppLink(siteConfig.contact.whatsapp, message), '_blank');
  };

  return (
    <>
      {/* Breadcrumb */}
      <div className="bg-gray-50 py-4">
        <div className="container-custom">
          <nav className="flex items-center gap-2 text-sm">
            <Link href="/" className="text-secondary-text hover:text-primary">
              Ana Sayfa
            </Link>
            <Icon name="chevron_right" className="!text-[16px] text-gray-400" />
            <Link href="/satilik-arsalar" className="text-secondary-text hover:text-primary">
              Satılık Arsalar
            </Link>
            <Icon name="chevron_right" className="!text-[16px] text-gray-400" />
            <span className="text-dark-charcoal font-medium">{listing.shortTitle}</span>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <section className="section">
        <div className="container-custom">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Left - Images & Details */}
            <div className="lg:col-span-2 space-y-6">
              {/* Main Image */}
              <div className="relative aspect-video bg-gray-100 rounded-2xl overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <Icon name="landscape" className="!text-[100px] text-gray-300" />
                </div>
                {/* Badges */}
                <div className="absolute top-4 left-4 flex gap-2">
                  {listing.isNew && (
                    <span className="badge-new">
                      <Icon name="fiber_new" className="!text-[14px] mr-1" />
                      Yeni
                    </span>
                  )}
                  {listing.isFeatured && (
                    <span className="badge-featured">
                      <Icon name="star" className="!text-[14px] mr-1" />
                      Fırsat
                    </span>
                  )}
                </div>
              </div>

              {/* Details */}
              <div className="card p-6">
                <h2 className="text-xl font-bold text-dark-charcoal mb-4">İlan Detayları</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="text-sm text-secondary-text mb-1">Ada/Parsel</div>
                    <div className="font-bold text-dark-charcoal">{listing.adaParsel}</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="text-sm text-secondary-text mb-1">Büyüklük</div>
                    <div className="font-bold text-dark-charcoal">{formatArea(listing.size)}</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="text-sm text-secondary-text mb-1">İmar Durumu</div>
                    <div className="font-bold text-dark-charcoal">{listing.imarDurumu}</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="text-sm text-secondary-text mb-1">Gabro</div>
                    <div className="font-bold text-dark-charcoal">{listing.gabroDurumu}</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="text-sm text-secondary-text mb-1">m² Fiyatı</div>
                    <div className="font-bold text-dark-charcoal">{formatPriceShort(listing.pricePerM2)}</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="text-sm text-secondary-text mb-1">Konum</div>
                    <div className="font-bold text-dark-charcoal">{listing.district}, {listing.city}</div>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="card p-6">
                <h2 className="text-xl font-bold text-dark-charcoal mb-4">Açıklama</h2>
                <p className="text-secondary-text leading-relaxed">{listing.description}</p>
              </div>

              {/* Features */}
              <div className="card p-6">
                <h2 className="text-xl font-bold text-dark-charcoal mb-4">Özellikler</h2>
                <div className="grid grid-cols-2 gap-3">
                  {listing.highlights.map((highlight, index) => (
                    <div key={index} className="flex items-center gap-2 text-dark-charcoal">
                      <Icon name="check_circle" className="!text-[20px] text-primary" />
                      <span>{highlight}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right - Sidebar */}
            <div className="space-y-6">
              {/* Price Card */}
              <div className="card p-6 sticky top-28">
                <div className="flex items-center justify-between mb-4">
                  <span className={`badge ${categoryColors.bg} ${categoryColors.text}`}>
                    {category?.label || listing.imarDurumu}
                  </span>
                  <span className="text-sm text-secondary-text">{formatArea(listing.size)}</span>
                </div>

                <h1 className="text-2xl font-black text-dark-charcoal mb-2">{listing.title}</h1>

                <div className="flex items-center gap-2 text-secondary-text mb-6">
                  <Icon name="location_on" className="!text-[18px]" />
                  <span>{listing.neighborhood}, {listing.district}, {listing.city}</span>
                </div>

                <div className="py-4 border-y border-gray-100 mb-6">
                  <div className="text-3xl font-black text-primary">{formatPriceShort(listing.price)}</div>
                  <div className="text-sm text-secondary-text">{formatPriceShort(listing.pricePerM2)}/m²</div>
                </div>

                {/* CTA Buttons */}
                <div className="space-y-3">
                  <button onClick={handleWhatsAppClick} className="btn-whatsapp btn-lg w-full">
                    <Icon name="chat_bubble" className="!text-[20px] mr-2" />
                    WhatsApp ile İletişim
                  </button>
                  <a href={siteConfig.contact.phoneLink} className="btn-primary btn-lg w-full">
                    <Icon name="phone" className="!text-[20px] mr-2" />
                    {siteConfig.contact.phone}
                  </a>
                </div>

                <p className="text-center text-sm text-secondary-text mt-4">
                  <Icon name="schedule" className="!text-[16px] inline mr-1" />
                  {siteConfig.contact.workingHours}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
