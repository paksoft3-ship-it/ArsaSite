import siteConfig from '@/data/site-config.json';
import Icon from '@/components/ui/Icon';

export default function ContactCTA() {
  return (
    <section className="py-12 bg-dark-charcoal">
      <div className="container-custom">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          {/* Text */}
          <div className="text-center sm:text-left">
            <h2 className="text-xl sm:text-2xl font-black text-white mb-1">
              Hemen İletişime Geçin
            </h2>
            <p className="text-gray-400 text-sm">
              Sorularınız mı var? Ekibimiz haftanın 7 günü hizmetinizde.
            </p>
          </div>

          {/* Buttons */}
          <div className="flex flex-wrap gap-3">
            <a
              href={siteConfig.contact.phoneLink}
              className="inline-flex items-center gap-2 bg-primary text-dark-charcoal px-5 py-3 rounded-xl font-bold text-sm hover:bg-primary-dark transition-colors"
            >
              <Icon name="phone" className="!text-[18px]" />
              {siteConfig.contact.phone}
            </a>
            <a
              href={siteConfig.contact.emailLink}
              className="inline-flex items-center gap-2 bg-white/10 text-white px-5 py-3 rounded-xl font-bold text-sm hover:bg-white/20 transition-colors"
            >
              <Icon name="mail" className="!text-[18px]" />
              E-posta Gönder
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
