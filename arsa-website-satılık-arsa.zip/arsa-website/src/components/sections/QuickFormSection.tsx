'use client';

import { useState } from 'react';
import homeContent from '@/data/home-content.json';
import siteConfig from '@/data/site-config.json';
import citiesData from '@/data/cities.json';
import Icon from '@/components/ui/Icon';
import { generateWhatsAppLink } from '@/lib/utils';

export default function QuickFormSection() {
  const { quickForm } = homeContent;
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    city: '',
    district: '',
    landType: '',
    size: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Generate WhatsApp message
    const message = `Merhaba, arsam için teklif almak istiyorum.

📋 Bilgilerim:
👤 Ad Soyad: ${formData.name}
📞 Telefon: ${formData.phone}
📍 Konum: ${formData.city}${formData.district ? ` / ${formData.district}` : ''}
${formData.landType ? `📌 Ada/Parsel: ${formData.landType}` : ''}
${formData.size ? `📐 Büyüklük: ${formData.size} m²` : ''}

Değerlendirmenizi bekliyorum. Teşekkürler.`;

    // Open WhatsApp with message
    const whatsappUrl = generateWhatsAppLink(siteConfig.contact.whatsapp, message);
    window.open(whatsappUrl, '_blank');

    setIsSubmitting(false);
  };

  return (
    <section className="section bg-white" id="quick-form">
      <div className="container-custom">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-10">
            <h2 className="section-title">{quickForm.title}</h2>
            <p className="section-description mx-auto">{quickForm.description}</p>
          </div>

          {/* Form Card */}
          <div className="card p-6 sm:p-8 lg:p-10">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Name */}
                <div>
                  <label htmlFor="name" className="label">
                    Ad Soyad <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Adınız Soyadınız"
                    required
                    className="input"
                  />
                </div>

                {/* Phone */}
                <div>
                  <label htmlFor="phone" className="label">
                    Telefon <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="05XX XXX XX XX"
                    required
                    className="input"
                  />
                </div>

                {/* City */}
                <div>
                  <label htmlFor="city" className="label">
                    Şehir <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="city"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    required
                    className="select"
                  >
                    <option value="">Şehir Seçin</option>
                    {citiesData.cities.map((city) => (
                      <option key={city.id} value={city.name}>
                        {city.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* District */}
                <div>
                  <label htmlFor="district" className="label">
                    İlçe
                  </label>
                  <input
                    type="text"
                    id="district"
                    name="district"
                    value={formData.district}
                    onChange={handleChange}
                    placeholder="İlçe Adı"
                    className="input"
                  />
                </div>

                {/* Land Type */}
                <div>
                  <label htmlFor="landType" className="label">
                    Ada/Parsel No (Opsiyonel)
                  </label>
                  <input
                    type="text"
                    id="landType"
                    name="landType"
                    value={formData.landType}
                    onChange={handleChange}
                    placeholder="Örn: 123/4"
                    className="input"
                  />
                </div>

                {/* Size */}
                <div>
                  <label htmlFor="size" className="label">
                    Büyüklük (m²)
                  </label>
                  <input
                    type="number"
                    id="size"
                    name="size"
                    value={formData.size}
                    onChange={handleChange}
                    placeholder="Örn: 500"
                    className="input"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary btn-lg w-full group"
              >
                {isSubmitting ? (
                  <>
                    <Icon name="sync" className="!text-[20px] mr-2 animate-spin" />
                    {quickForm.submitButton.loadingLabel}
                  </>
                ) : (
                  <>
                    <Icon name="send" className="!text-[20px] mr-2" />
                    {quickForm.submitButton.label}
                  </>
                )}
              </button>

              {/* Privacy Note */}
              <p className="text-center text-sm text-secondary-text">
                <Icon name="lock" className="!text-[16px] inline mr-1" />
                {quickForm.privacyNote}
              </p>
            </form>

            {/* Phone Note */}
            <div className="mt-6 pt-6 border-t border-gray-100 text-center">
              <p className="text-secondary-text text-sm">
                {quickForm.phoneNote.split(':')[0]}:{' '}
                <a
                  href={siteConfig.contact.phoneLink}
                  className="font-bold text-dark-charcoal hover:text-primary transition-colors"
                >
                  {siteConfig.contact.phone}
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
