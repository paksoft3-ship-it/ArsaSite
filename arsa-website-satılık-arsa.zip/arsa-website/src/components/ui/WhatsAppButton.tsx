'use client';

import { useState, useEffect } from 'react';
import siteConfig from '@/data/site-config.json';
import { cn } from '@/lib/utils';

export default function WhatsAppButton() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 300);
    };

    // Show after initial load
    const timer = setTimeout(() => setIsVisible(true), 2000);

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearTimeout(timer);
    };
  }, []);

  const message = encodeURIComponent(
    'Merhaba, arsam hakkında bilgi almak istiyorum.'
  );

  return (
    <a
      href={`${siteConfig.contact.whatsappLink}?text=${message}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="WhatsApp ile iletişime geçin"
      className={cn(
        'fixed bottom-6 right-6 z-50 flex h-14 w-14 sm:h-16 sm:w-16 items-center justify-center',
        'rounded-full bg-[#25D366] text-white shadow-lg shadow-green-900/30',
        'hover:scale-110 hover:shadow-xl transition-all duration-300',
        'whatsapp-btn',
        isVisible
          ? 'opacity-100 translate-y-0'
          : 'opacity-0 translate-y-4 pointer-events-none'
      )}
    >
      <svg
        fill="currentColor"
        height="32"
        width="32"
        viewBox="0 0 24 24"
        xmlns="http://www.w3.org/2000/svg"
        className="sm:w-9 sm:h-9"
      >
        <path
          clipRule="evenodd"
          fillRule="evenodd"
          d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.592 2.664-.698c.975.551 1.803.842 2.803.843 3.179 0 5.767-2.587 5.767-5.766.001-3.187-2.575-5.77-5.774-5.771zm3.392 8.244c-1.352.766-1.895 1.391-2.909 1.258-1.577-.206-3.235-1.921-3.951-3.136-.379-.641-.186-1.488.468-2.076.166-.149.37-.215.549-.215.228 0 .395.006.474.019.222.035.348.118.423.298.196.475.642 1.638.691 1.748.061.135.035.298-.078.498-.148.263-.332.391-.482.569-.136.161-.284.281-.132.541.348.598 1.484 1.838 2.378 2.214.281.118.513.067.688-.135.201-.231.523-.695.696-.918.158-.205.356-.166.578-.083.216.082 1.383.652 1.62.77.237.118.395.176.452.275.059.1.059.576-.234 1.391zM12 2C6.48 2 2 6.48 2 12c0 1.82.49 3.53 1.35 5l-1.35 4.9 5.09-1.33C8.6 21.6 10.25 22 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2z"
        />
      </svg>
    </a>
  );
}
