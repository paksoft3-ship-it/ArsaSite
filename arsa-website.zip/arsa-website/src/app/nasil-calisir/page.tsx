import type { Metadata } from 'next';
import Link from 'next/link';
import { generateMetadata as genMeta } from '@/lib/seo';
import homeContent from '@/data/home-content.json';
import siteConfig from '@/data/site-config.json';
import Icon from '@/components/ui/Icon';

export const metadata: Metadata = genMeta({
  title: 'Nasıl Çalışır?',
  description: 'Arsanızı 4 basit adımda nakite çevirin. Bilgi verin, değerlendirme alın, teklif alın, ödeme alın.',
  url: '/nasil-calisir',
});

export default function HowItWorksPage() {
  const { process, whyUs } = homeContent;

  return (
    <>
      {/* Hero */}
      <section className="bg-gradient-to-br from-dark-charcoal to-surface-dark py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-map-pattern opacity-10" />
        <div className="container-custom relative">
          <div className="max-w-3xl">
            <h1 className="text-4xl sm:text-5xl font-black text-white tracking-tight mb-6">
              Nasıl Çalışır?
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed mb-8">
              Arsanızı satmak hiç bu kadar kolay olmamıştı. 4 basit adımda arsanızı nakite çevirin.
            </p>
            <Link href="/arsa-sat" className="btn-primary btn-lg">
              Hemen Başla
              <Icon name="arrow_forward" className="!text-[20px] ml-2" />
            </Link>
          </div>
        </div>
      </section>

      {/* Steps */}
      <section className="section bg-white">
        <div className="container-custom">
          <div className="space-y-16">
            {process.steps.map((step, index) => (
              <div
                key={index}
                className={`grid lg:grid-cols-2 gap-8 lg:gap-16 items-center ${
                  index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                }`}
              >
                <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                  <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-bold mb-4">
                    Adım {step.number}
                  </div>
                  <h2 className="text-3xl font-black text-dark-charcoal mb-4">{step.title}</h2>
                  <p className="text-secondary-text text-lg leading-relaxed mb-6">
                    {step.description}
                  </p>
                  <div className="inline-flex items-center gap-2 text-sm text-primary font-bold">
                    <Icon name="schedule" className="!text-[18px]" />
                    {step.duration}
                  </div>
                </div>
                <div className={`${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                  <div className="bg-gray-100 rounded-3xl aspect-video flex items-center justify-center">
                    <div className="w-24 h-24 rounded-2xl bg-primary/20 flex items-center justify-center">
                      <Icon name={step.icon} className="!text-[48px] text-primary" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Us */}
      <section className="section bg-background-light">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="section-title">{whyUs.title}</h2>
            <p className="section-description mx-auto">{whyUs.description}</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {whyUs.features.map((feature, index) => (
              <div key={index} className="card p-6 hover:shadow-card-hover transition-all">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                  <Icon name={feature.icon} className="!text-[24px] text-primary" />
                </div>
                <h3 className="font-bold text-dark-charcoal mb-2">{feature.title}</h3>
                <p className="text-secondary-text text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section bg-dark-charcoal relative overflow-hidden">
        <div className="absolute inset-0 bg-map-pattern opacity-10" />
        <div className="container-custom relative text-center">
          <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">
            Hemen Başlayın
          </h2>
          <p className="text-gray-300 text-lg max-w-xl mx-auto mb-8">
            Arsanız için aynı gün nakit teklif alın. Ücretsiz değerlendirme, hızlı süreç.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/arsa-sat" className="btn-primary btn-lg">
              Teklif Al
              <Icon name="arrow_forward" className="!text-[20px] ml-2" />
            </Link>
            <a
              href={siteConfig.contact.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-whatsapp btn-lg"
            >
              <Icon name="chat_bubble" className="!text-[20px] mr-2" />
              WhatsApp ile Yazın
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
