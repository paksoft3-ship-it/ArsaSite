'use client';

import { useState, useMemo } from 'react';
import listingsData from '@/data/listings.json';
import Icon from '@/components/ui/Icon';
import ListingCard from '@/components/cards/ListingCard';

export default function ListingsPageContent() {
  const [filters, setFilters] = useState({
    city: '',
    category: '',
    sort: 'newest',
  });

  const filteredListings = useMemo(() => {
    let result = [...listingsData.listings];

    // Filter by city
    if (filters.city) {
      result = result.filter(
        (l) => l.city.toLowerCase() === filters.city.toLowerCase()
      );
    }

    // Filter by category
    if (filters.category) {
      result = result.filter((l) => l.category === filters.category);
    }

    // Sort
    switch (filters.sort) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'size-asc':
        result.sort((a, b) => a.size - b.size);
        break;
      case 'size-desc':
        result.sort((a, b) => b.size - a.size);
        break;
      default:
        result.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
    }

    return result;
  }, [filters]);

  const handleFilterChange = (
    e: React.ChangeEvent<HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const clearFilters = () => {
    setFilters({ city: '', category: '', sort: 'newest' });
  };

  return (
    <>
      {/* Page Header */}
      <section className="bg-gradient-to-br from-background-light to-primary/5 py-12">
        <div className="container-custom">
          <h1 className="text-4xl sm:text-5xl font-black text-dark-charcoal tracking-tight mb-4">
            Satılık Arsalar
          </h1>
          <p className="text-lg text-secondary-text max-w-2xl">
            Türkiye genelinde yatırımlık ve kullanıma hazır arsa ilanlarımızı keşfedin. Size en uygun arsayı bulmak için filtreleri kullanın.
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="py-6 border-b border-gray-100 bg-white sticky top-16 sm:top-20 z-30">
        <div className="container-custom">
          <div className="flex flex-wrap items-center gap-4">
            {/* City Filter */}
            <div className="flex-1 min-w-[150px]">
              <select
                name="city"
                value={filters.city}
                onChange={handleFilterChange}
                className="select"
              >
                {listingsData.filters.cities.map((city) => (
                  <option key={city.value} value={city.value}>
                    {city.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Category Filter */}
            <div className="flex-1 min-w-[150px]">
              <select
                name="category"
                value={filters.category}
                onChange={handleFilterChange}
                className="select"
              >
                <option value="">Tüm Kategoriler</option>
                {listingsData.categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort */}
            <div className="flex-1 min-w-[150px]">
              <select
                name="sort"
                value={filters.sort}
                onChange={handleFilterChange}
                className="select"
              >
                {listingsData.filters.sortOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Clear Filters */}
            {(filters.city || filters.category) && (
              <button
                onClick={clearFilters}
                className="btn-ghost btn-sm text-secondary-text"
              >
                <Icon name="close" className="!text-[18px] mr-1" />
                Temizle
              </button>
            )}

            {/* Results Count */}
            <div className="text-sm text-secondary-text">
              <span className="font-bold text-dark-charcoal">{filteredListings.length}</span> ilan bulundu
            </div>
          </div>
        </div>
      </section>

      {/* Listings Grid */}
      <section className="section bg-background-light">
        <div className="container-custom">
          {filteredListings.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredListings.map((listing) => (
                <ListingCard key={listing.id} listing={listing} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Icon name="search_off" className="!text-[64px] text-gray-300 mb-4" />
              <h3 className="text-xl font-bold text-dark-charcoal mb-2">
                İlan Bulunamadı
              </h3>
              <p className="text-secondary-text mb-6">
                Seçtiğiniz kriterlere uygun ilan bulunamadı. Filtreleri değiştirerek tekrar deneyin.
              </p>
              <button onClick={clearFilters} className="btn-primary btn-md">
                Filtreleri Temizle
              </button>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
