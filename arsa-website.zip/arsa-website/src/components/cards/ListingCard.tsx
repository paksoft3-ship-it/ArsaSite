import Link from 'next/link';
import type { Listing } from '@/types';
import listingsData from '@/data/listings.json';
import Icon from '@/components/ui/Icon';
import { formatPriceShort, formatArea, getCategoryColorClasses } from '@/lib/utils';

interface ListingCardProps {
  listing: Listing;
}

export default function ListingCard({ listing }: ListingCardProps) {
  const category = listingsData.categories.find(c => c.id === listing.category);
  const categoryColors = category ? getCategoryColorClasses(category.color) : getCategoryColorClasses('emerald');

  return (
    <Link
      href={`/satilik-arsalar/${listing.slug}`}
      className="card card-hover group block overflow-hidden"
    >
      {/* Image Container */}
      <div className="relative aspect-card bg-gray-100 overflow-hidden">
        {/* Placeholder - replace with actual image */}
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200">
          <Icon name="landscape" className="!text-[60px] text-gray-300 group-hover:scale-110 transition-transform duration-500" />
        </div>

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-2">
          {listing.isNew && (
            <span className="badge-new">
              <Icon name="fiber_new" className="!text-[14px] mr-1" />
              Yeni
            </span>
          )}
          {listing.isFeatured && (
            <span className="badge-featured">
              <Icon name="star" className="!text-[14px] mr-1" />
              Fırsat
            </span>
          )}
        </div>

        {/* Photo Count */}
        <div className="absolute bottom-3 right-3 bg-black/60 text-white px-2 py-1 rounded-lg text-xs flex items-center gap-1">
          <Icon name="photo_camera" className="!text-[14px]" />
          {listing.photoCount}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Category & Size */}
        <div className="flex items-center justify-between mb-2">
          <span className={`badge ${categoryColors.bg} ${categoryColors.text}`}>
            {category?.label || listing.imarDurumu}
          </span>
          <span className="text-sm text-secondary-text">{formatArea(listing.size)}</span>
        </div>

        {/* Title */}
        <h3 className="font-bold text-dark-charcoal group-hover:text-primary transition-colors line-clamp-2 mb-2">
          {listing.title}
        </h3>

        {/* Location */}
        <div className="flex items-center gap-1 text-secondary-text text-sm mb-4">
          <Icon name="location_on" className="!text-[16px]" />
          <span>{listing.district}, {listing.city}</span>
        </div>

        {/* Price */}
        <div className="pt-3 border-t border-gray-100 flex items-end justify-between">
          <div>
            <div className="text-xl font-black text-primary">{formatPriceShort(listing.price)}</div>
            <div className="text-xs text-secondary-text">{formatPriceShort(listing.pricePerM2)}/m²</div>
          </div>
          <span className="text-primary group-hover:translate-x-1 transition-transform">
            <Icon name="arrow_forward" className="!text-[20px]" />
          </span>
        </div>
      </div>
    </Link>
  );
}
