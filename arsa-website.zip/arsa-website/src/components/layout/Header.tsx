'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import siteConfig from '@/data/site-config.json';
import { cn } from '@/lib/utils';
import Icon from '@/components/ui/Icon';

const navItems = [
  { id: 'home', label: 'Anasayfa', href: '/' },
  { id: 'satilik-arsalar', label: 'Satılık Arsalar', href: '/satilik-arsalar' },
  { id: 'hakkimizda', label: 'Hakkımızda', href: '/hakkimizda' },
  { id: 'iletisim', label: 'İletişim', href: '/iletisim' },
];

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [pathname]);

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };

  return (
    <header
      className={cn(
        'sticky top-0 z-50 w-full transition-all duration-300',
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-gray-100'
          : 'bg-white border-b border-gray-100'
      )}
    >
      <div className="container-custom">
        <div className="flex h-16 sm:h-18 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-1.5 group">
            <div className="text-primary">
              <Icon name="landscape" className="!text-[28px]" />
            </div>
            <span className="text-xl font-black tracking-tight">
              <span className="text-dark-charcoal">Arsa</span>
              <span className="text-primary">Borsası</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.id}
                href={item.href}
                className={cn(
                  'px-4 py-2 text-sm font-medium rounded-lg transition-colors',
                  isActive(item.href)
                    ? 'text-primary'
                    : 'text-dark-charcoal/70 hover:text-primary'
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {/* Hesabım - desktop only */}
            <Link
              href="/hesabim"
              className="hidden md:flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-dark-charcoal/70 hover:text-primary transition-colors"
            >
              <Icon name="person" className="!text-[18px]" />
              Hesabım
            </Link>

            {/* CTA Button */}
            <Link
              href="/arsa-sat"
              className="btn-primary px-5 py-2.5 text-sm"
            >
              Teklif Al
            </Link>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Menu"
              aria-expanded={isMobileMenuOpen}
              className="flex md:hidden icon-btn-md bg-gray-100 text-dark-charcoal"
            >
              <Icon name={isMobileMenuOpen ? 'close' : 'menu'} />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={cn(
          'md:hidden absolute top-full left-0 right-0 bg-white border-b border-gray-100 shadow-lg transition-all duration-300',
          isMobileMenuOpen
            ? 'opacity-100 translate-y-0'
            : 'opacity-0 -translate-y-4 pointer-events-none'
        )}
      >
        <nav className="container-custom py-4">
          <div className="flex flex-col gap-1">
            {navItems.map((item) => (
              <Link
                key={item.id}
                href={item.href}
                className={cn(
                  'flex items-center gap-3 px-4 py-3 rounded-xl transition-colors',
                  isActive(item.href)
                    ? 'text-primary bg-primary/5'
                    : 'text-dark-charcoal hover:bg-gray-50'
                )}
              >
                <span className="font-medium">{item.label}</span>
              </Link>
            ))}
          </div>

          {/* Mobile Contact */}
          <div className="mt-4 pt-4 border-t border-gray-100 flex flex-col gap-2">
            <a
              href={siteConfig.contact.phoneLink}
              className="flex items-center gap-3 px-4 py-3 rounded-xl bg-gray-50 text-dark-charcoal"
            >
              <Icon name="phone" className="!text-[20px]" />
              <span className="font-medium">{siteConfig.contact.phone}</span>
            </a>
            <a
              href={siteConfig.contact.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 px-4 py-3 rounded-xl bg-[#25D366]/10 text-[#25D366]"
            >
              <Icon name="chat_bubble" className="!text-[20px]" />
              <span className="font-medium">WhatsApp ile Yazın</span>
            </a>
          </div>
        </nav>
      </div>
    </header>
  );
}
