import Link from 'next/link';
import homeContent from '@/data/home-content.json';
import siteConfig from '@/data/site-config.json';
import Icon from '@/components/ui/Icon';

export default function CTASection() {
  const { contactCta } = homeContent;

  return (
    <section className="section bg-dark-charcoal relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-map-pattern opacity-20" />
      
      {/* Gradient Overlays */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />

      <div className="container-custom relative z-10">
        <div className="text-center max-w-2xl mx-auto">
          {/* Title */}
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight mb-4">
            {contactCta.title}
          </h2>
          <p className="text-white/70 text-lg mb-8">
            {contactCta.description}
          </p>

          {/* Contact Options */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            {/* Phone */}
            <a
              href={siteConfig.contact.phoneLink}
              className="group flex items-center gap-3 bg-white/10 hover:bg-white/20 rounded-2xl px-6 py-4 transition-all"
            >
              <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
                <Icon name="phone" className="!text-[24px] text-dark-charcoal" />
              </div>
              <div className="text-left">
                <p className="text-white/60 text-sm">Bizi Arayın</p>
                <p className="text-white font-bold text-lg">{siteConfig.contact.phone}</p>
              </div>
            </a>

            {/* WhatsApp */}
            <a
              href={`${siteConfig.contact.whatsappLink}?text=${encodeURIComponent('Merhaba, arsam hakkında bilgi almak istiyorum.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-3 bg-[#25D366]/20 hover:bg-[#25D366]/30 rounded-2xl px-6 py-4 transition-all"
            >
              <div className="w-12 h-12 rounded-xl bg-[#25D366] flex items-center justify-center">
                <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.592 2.664-.698c.975.551 1.803.842 2.803.843 3.179 0 5.767-2.587 5.767-5.766.001-3.187-2.575-5.77-5.774-5.771zm3.392 8.244c-.14.393-.73.719-1.01.757-.23.032-.52.046-.84-.053-.19-.06-.44-.14-.76-.27-1.34-.58-2.22-1.93-2.29-2.02-.07-.09-.56-.75-.56-1.43 0-.68.36-1.01.48-1.15.13-.14.28-.17.37-.17.09 0 .18 0 .26.01.08 0 .19-.03.3.23.11.26.39.95.42 1.02.03.07.06.15.01.24-.04.09-.07.15-.14.23-.07.08-.14.18-.21.24-.07.07-.14.14-.06.28.08.13.36.6.77.97.53.48.98.63 1.12.7.14.07.22.06.3-.04.08-.09.36-.42.46-.56.1-.15.19-.12.33-.07.13.05.85.4.99.47.15.07.24.11.28.17.03.06.03.35-.11.68zM12 2C6.48 2 2 6.48 2 12c0 1.82.49 3.53 1.35 5l-1.35 4.9 5.09-1.33C8.6 21.6 10.25 22 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2z"/>
                </svg>
              </div>
              <div className="text-left">
                <p className="text-white/60 text-sm">WhatsApp</p>
                <p className="text-white font-bold text-lg">Hemen Yazın</p>
              </div>
            </a>
          </div>

          {/* Main CTA Button */}
          <div className="mt-8">
            <Link href="/arsa-sat" className="btn-primary btn-lg">
              <Icon name="sell" className="mr-2 !text-[20px]" />
              Ücretsiz Teklif Al
            </Link>
          </div>

          {/* Trust Note */}
          <p className="mt-6 text-white/50 text-sm flex items-center justify-center gap-2">
            <Icon name="verified_user" className="!text-[18px]" />
            Tüm görüşmeleriniz gizli tutulur
          </p>
        </div>
      </div>
    </section>
  );
}
