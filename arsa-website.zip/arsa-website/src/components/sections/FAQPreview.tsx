'use client';

import { useState } from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/Icon';

const faqItems = [
  {
    question: 'Teklif süreci ne kadar sürüyor?',
    answer: 'Arsanızın bilgilerini aldıktan sonra genellikle 24 saat içinde size nakit teklifimizi iletiyoruz.',
  },
  {
    question: 'Hisseli tapular için teklif veriyor musunuz?',
    answer: 'Evet, hisseli tapular için de değerlendirme yapıyor ve teklif veriyoruz. Hukuk ekibimiz gerekli süreçlerde size destek sağlar.',
  },
  {
    question: 'Ödeme güvenliği nasıl sağlanıyor?',
    answer: 'Ödemeler tapu devri sırasında banka transferi ile yapılmaktadır. Tüm işlemler yasal ve güvenli şekilde gerçekleştirilir.',
  },
  {
    question: 'Değerleme ücreti alıyor musunuz?',
    answer: 'Hayır, ön değerlendirme tamamen ücretsizdir. Teklifi kabul etmezseniz herhangi bir ücret ödemeniz gerekmez.',
  },
  {
    question: 'Hangi illerde hizmet veriyorsunuz?',
    answer: 'Türkiye\'nin 81 ilinde hizmet veriyoruz. Şehir merkezi veya kırsal bölge fark etmeksizin tüm arsalarınız için teklif alabiliriz.',
  },
];

export default function FAQPreview() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleQuestion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-16 bg-white">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-2xl sm:text-3xl font-black text-dark-charcoal tracking-tight">
            Sıkça Sorulan Sorular
          </h2>
        </div>

        {/* FAQ Items */}
        <div className="max-w-3xl mx-auto space-y-3">
          {faqItems.map((item, index) => (
            <div
              key={index}
              className="bg-background-light rounded-xl overflow-hidden"
            >
              <button
                onClick={() => toggleQuestion(index)}
                className="w-full flex items-center justify-between p-5 text-left hover:bg-gray-100 transition-colors"
              >
                <span className="font-semibold text-dark-charcoal pr-4">
                  {item.question}
                </span>
                <Icon
                  name={openIndex === index ? 'expand_less' : 'expand_more'}
                  className="!text-[24px] flex-shrink-0 text-secondary-text"
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <p className="px-5 pb-5 text-secondary-text leading-relaxed">
                  {item.answer}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* View All Link */}
        <div className="text-center mt-8">
          <Link
            href="/sss"
            className="inline-flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all text-sm"
          >
            Tüm soruları gör
            <Icon name="arrow_forward" className="!text-[18px]" />
          </Link>
        </div>
      </div>
    </section>
  );
}
