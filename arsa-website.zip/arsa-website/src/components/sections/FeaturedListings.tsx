import Link from 'next/link';
import listingsData from '@/data/listings.json';
import Icon from '@/components/ui/Icon';
import { formatPriceShort, formatArea } from '@/lib/utils';

export default function FeaturedListings() {
  const featured = listingsData.listings.filter(listing => listing.isFeatured).slice(0, 4);

  // Sample images for demo - replace with actual images
  const sampleImages = [
    'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&h=400&fit=crop',
    'https://images.unsplash.com/photo-1628624747186-a941c476b7ef?w=600&h=400&fit=crop',
    'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop',
    'https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=600&h=400&fit=crop',
  ];

  const getCategoryLabel = (category: string) => {
    const cat = listingsData.categories.find(c => c.id === category);
    return cat?.label || category;
  };

  return (
    <section className="py-16 bg-white">
      <div className="container-custom">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-10">
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-dark-charcoal tracking-tight">
              Fırsat Niteliğindeki Arsalar
            </h2>
            <p className="text-secondary-text mt-2">
              Yatırımlık veya projeye uygun, tapusu hazır seçili ilanlarımız.
            </p>
          </div>
          <Link
            href="/satilik-arsalar"
            className="inline-flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all text-sm"
          >
            Tüm İlanları Gör
            <Icon name="arrow_forward" className="!text-[18px]" />
          </Link>
        </div>

        {/* Listings Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featured.map((listing, index) => (
            <Link
              key={listing.id}
              href={`/satilik-arsalar/${listing.slug}`}
              className="group block"
            >
              {/* Image Container */}
              <div className="relative aspect-[4/3] rounded-2xl overflow-hidden mb-4">
                {/* Background Image */}
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                  style={{ 
                    backgroundImage: `url(${sampleImages[index % sampleImages.length]})`,
                    backgroundColor: '#e5e7eb'
                  }}
                />
                
                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />

                {/* Category Badge - Top Left */}
                <div className="absolute top-3 left-3">
                  <span className="inline-block bg-primary text-dark-charcoal text-xs font-bold px-3 py-1.5 rounded-lg uppercase tracking-wide">
                    {getCategoryLabel(listing.category)}
                  </span>
                </div>

                {/* Size Badge - Top Right */}
                <div className="absolute top-3 right-3">
                  <span className="inline-block bg-white/90 text-dark-charcoal text-xs font-semibold px-3 py-1.5 rounded-lg">
                    {formatArea(listing.size)}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div>
                <h3 className="font-bold text-dark-charcoal group-hover:text-primary transition-colors mb-1">
                  {listing.shortTitle}
                </h3>
                <div className="flex items-center gap-1 text-secondary-text text-sm mb-3">
                  <Icon name="location_on" className="!text-[16px]" />
                  <span>{listing.district}, {listing.city}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-black text-primary">
                    {formatPriceShort(listing.price)}
                  </span>
                  <span className="text-primary text-sm font-semibold group-hover:underline">
                    İncele
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Floating Chat Button */}
        <div className="hidden lg:block fixed right-6 bottom-32 z-40">
          <a
            href="#quick-form"
            className="flex items-center justify-center w-14 h-14 rounded-full bg-primary text-dark-charcoal shadow-lg hover:scale-110 transition-transform"
            aria-label="Form'a Git"
          >
            <Icon name="chat_bubble" className="!text-[24px]" />
          </a>
        </div>
      </div>
    </section>
  );
}
